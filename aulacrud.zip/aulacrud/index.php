<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aula PHP</title>
</head>
<body>

<form action="cadastrar.php" method="post">

    <input type="text" name="nome" placeholder="Digite seu nome">

    <input type="text" name="sobrenome" placeholder="Digite seu sobrenome">

    <input type="date" name="datanasc">

    <input type="submit" value="Cadastrar">

</form>


<h2>Lista de Usuários</h2>

<table border="1" cellpadding="10">
    <tr>
        <th>id</th>
        <th>nome</th>
        <th>sobrenome</th>
        <th>datanasc</th>
       
    </tr>
    <?php
require('conexao.php');

$sql = "SELECT * FROM cadastro";
$statement = $pdo->query($sql);
$usuarios = $statement->fetchAll(PDO::FETCH_ASSOC);
?>

    <?php foreach($usuarios as $usuario): ?>
    <tr>
        <td><?= $usuario['id']; ?></td>
        <td><?= $usuario['nome']; ?></td>
        <td><?= $usuario['sobrenome']; ?></td>
        <td><?= $usuario['datanasc']; ?></td>

        <td>
            <a href="editar.php?id=<?= $usuario['id']; ?>">Editar</a>
            <a href="deletar.php?id=<?= $usuario['id']; ?>">Excluir</a>
        </td>
    </tr>
    <?php endforeach; ?>

</table>

<br>




</body>
</html>